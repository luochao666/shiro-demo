CREATE TRIGGER WWV_FLOW_PURGED_SESS_BIU
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_PURGED_SESSIONS$
  FOR EACH ROW
begin
    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
end;
/

