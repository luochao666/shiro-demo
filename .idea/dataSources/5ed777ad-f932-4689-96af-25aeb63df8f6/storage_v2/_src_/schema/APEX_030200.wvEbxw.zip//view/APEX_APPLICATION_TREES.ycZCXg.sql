CREATE VIEW APEX_APPLICATION_TREES AS
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.TREE_NAME                      tree_name,
    t.TREE_TYPE                      tree_type,
    t.TREE_QUERY                     tree_query,
    t.FLOW_ITEM                      ,
    t.MAX_LEVELS                     maximum_levels,
    t.UNEXPANDED_PARENT              ,
    t.UNEXPANDED_PARENT_LAST         ,
    t.EXPANDED_PARENT                ,
    t.EXPANDED_PARENT_LAST           ,
    t.LEAF_NODE                      ,
    t.LEAF_NODE_LAST                 ,
    t.DRILL_UP                       ,
    t.NAME_LINK_ANCHOR_TAG           ,
    t.NAME_LINK_NOT_ANCHOR_TAG       ,
    t.INDENT_VERTICAL_LINE           ,
    t.INDENT_VERTICAL_LINE_LAST      ,
    t.BEFORE_TREE                    ,
    t.AFTER_TREE                     ,
    t.LEVEL_1_TEMPLATE               ,
    t.LEVEL_2_TEMPLATE               ,
    t.LEVEL_3_TEMPLATE               ,
    t.LEVEL_4_TEMPLATE               ,
    t.LEVEL_5_TEMPLATE               ,
    t.LEVEL_6_TEMPLATE               ,
    t.LEVEL_7_TEMPLATE               ,
    t.LEVEL_8_TEMPLATE               ,
    --
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    --
    t.TREE_COMMENT                   component_comment,
    t.id                             application_tree_id,
    --
    t.TREE_NAME
    ||' t='||t.TREE_TYPE
    ||substr(t.TREE_QUERY,1,50)||length(t.tree_query)
    ||' i='||t.FLOW_ITEM
    ||' l='||t.MAX_LEVELS
    ||'.'||length(t.UNEXPANDED_PARENT        )
    ||'.'||length(t.UNEXPANDED_PARENT_LAST   )
    ||'.'||length(t.EXPANDED_PARENT          )
    ||'.'||length(t.EXPANDED_PARENT_LAST     )
    ||'.'||length(t.LEAF_NODE                )
    ||'.'||length(t.LEAF_NODE_LAST           )
    ||'.'||length(t.DRILL_UP                 )
    ||'.'||length(t.NAME_LINK_ANCHOR_TAG     )
    ||'.'||length(t.NAME_LINK_NOT_ANCHOR_TAG )
    ||'.'||length(t.INDENT_VERTICAL_LINE     )
    ||'.'||length(t.INDENT_VERTICAL_LINE_LAST)
    ||'.'||length(t.BEFORE_TREE              )
    ||'.'||length(t.AFTER_TREE               )
    ||'.'||length(t.LEVEL_1_TEMPLATE         )
    ||'.'||length(t.LEVEL_2_TEMPLATE         )
    ||'.'||length(t.LEVEL_3_TEMPLATE         )
    ||'.'||length(t.LEVEL_4_TEMPLATE         )
    ||'.'||length(t.LEVEL_5_TEMPLATE         )
    ||'.'||length(t.LEVEL_6_TEMPLATE         )
    ||'.'||length(t.LEVEL_7_TEMPLATE         )
    ||'.'||length(t.LEVEL_8_TEMPLATE         )
    component_signature
from wwv_flow_trees t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

COMMENT ON TABLE APEX_APPLICATION_TREES IS 'Identifies a tree control which can be referenced and displayed by creating a region with a source of this tree'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.WORKSPACE IS 'A work area mapped to one or more database schemas'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.APPLICATION_NAME IS 'Identifies the application'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.TREE_NAME IS 'Component name'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.TREE_TYPE IS 'Tree component type'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.TREE_QUERY IS 'Query which will be used to generate this tree'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.FLOW_ITEM IS 'Identifies an application or page item which specifies the starting point of the tree'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.MAXIMUM_LEVELS IS 'This attribute specifies how many levels will appear when a tree first displays'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.UNEXPANDED_PARENT IS 'HTML template for unexpanded parent nodes'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.UNEXPANDED_PARENT_LAST IS 'HTML template for the last unexpanded parent node'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.EXPANDED_PARENT IS 'HTML template for the expanded parent node'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.EXPANDED_PARENT_LAST IS 'HTML template for the last expanded parent node'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.LEAF_NODE IS 'Controls the text that is painted before showing the text of the leaf node'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.LEAF_NODE_LAST IS 'Controls the text that is painted before showing the text of the last leaf node.'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.DRILL_UP IS 'Identifies the link text shown when drilling up is possible in the tree'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.NAME_LINK_ANCHOR_TAG IS 'Identifies the manner in which a Name will render if the name has a link'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.NAME_LINK_NOT_ANCHOR_TAG IS 'Tag for node names which are not links'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.INDENT_VERTICAL_LINE IS 'Controls vertical line or spacing between peers'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.INDENT_VERTICAL_LINE_LAST IS 'Indent Vertical Line Last, controls a blank space'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.BEFORE_TREE IS 'Text before displaying any nodes of the tree'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.AFTER_TREE IS 'Text after displaying nodes of the tree'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.LEVEL_1_TEMPLATE IS 'Parent Node Template'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.LEVEL_2_TEMPLATE IS 'Node Text Template'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.LAST_UPDATED_BY IS 'Apex developer who made last update'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.LAST_UPDATED_ON IS 'Date of last update'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.COMPONENT_COMMENT IS 'Developer comment'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.APPLICATION_TREE_ID IS 'Primary Key of this Application Tree shared component'
/

COMMENT ON COLUMN APEX_APPLICATION_TREES.COMPONENT_SIGNATURE IS 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

