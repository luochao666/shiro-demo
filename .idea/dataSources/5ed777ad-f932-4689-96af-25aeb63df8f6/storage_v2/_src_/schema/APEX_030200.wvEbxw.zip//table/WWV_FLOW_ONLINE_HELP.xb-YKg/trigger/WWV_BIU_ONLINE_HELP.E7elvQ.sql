CREATE TRIGGER WWV_BIU_ONLINE_HELP
  BEFORE INSERT
  ON WWV_FLOW_ONLINE_HELP
  FOR EACH ROW
begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
end;
/

