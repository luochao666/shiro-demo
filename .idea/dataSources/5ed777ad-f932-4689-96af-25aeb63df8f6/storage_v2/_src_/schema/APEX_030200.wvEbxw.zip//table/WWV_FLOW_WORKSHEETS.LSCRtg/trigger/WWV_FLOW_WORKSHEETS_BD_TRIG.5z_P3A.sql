CREATE TRIGGER WWV_FLOW_WORKSHEETS_BD_TRIG
  BEFORE DELETE
  ON WWV_FLOW_WORKSHEETS
begin
    wwv_flow_worksheet.g_delete_in_progress := true;
end;
/

