CREATE VIEW WWV_FLOW_MONTHS_MON AS
select "MONTH_DISPLAY","MONTH_VALUE" from wwv_flow_months_mon_temp where month_value < 13
/

