CREATE VIEW APEX_APPLICATION_BUILD_OPTIONS AS
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    b.PATCH_NAME                     build_option_name,
    decode(b.PATCH_STATUS,
        'INCLUDE','Include',
        'EXCLUDE','Exclude',
        b.patch_status)              build_option_status,
    decode(nvl(b.DEFAULT_ON_EXPORT,
        b.patch_status),
        'INCLUDE','Include',
        'EXCLUDE','Exclude',
        b.DEFAULT_ON_EXPORT)         status_on_export,
    --b.ATTRIBUTE1                   attribute1,
    --b.ATTRIBUTE2                   attribute2,
    --b.ATTRIBUTE3                   attribute3,
    --b.ATTRIBUTE4                   attribute4,
    b.LAST_UPDATED_BY                last_updated_by,
    b.LAST_UPDATED_ON                last_updated_on,
    b.PATCH_COMMENT                  component_comment,
    b.id                             build_option_id,
    --
    b.PATCH_NAME
    ||' s='||decode(b.PATCH_STATUS,
        'INCLUDE','Include',
        'EXCLUDE','Exclude',
        b.patch_status)
    ||' e='||decode(nvl(b.DEFAULT_ON_EXPORT,
        b.patch_status),
        'INCLUDE','Include',
        'EXCLUDE','Exclude',
        b.DEFAULT_ON_EXPORT)
    component_signature
from wwv_flow_patches b,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_030200')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = b.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0 and
      (user in ('SYS','SYSTEM', 'APEX_030200') or w.PROVISIONING_COMPANY_ID != 10)
/

COMMENT ON TABLE APEX_APPLICATION_BUILD_OPTIONS IS 'Identifies Build Options available to an application'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.WORKSPACE IS 'A work area mapped to one or more database schemas'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.APPLICATION_ID IS 'Application Primary Key, Unique over all workspaces'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.APPLICATION_NAME IS 'Identifies the application'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.BUILD_OPTION_NAME IS 'Identifies the build option'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.BUILD_OPTION_STATUS IS 'Identifies the current status of the Build option; Include or Exclude.'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.STATUS_ON_EXPORT IS 'Identifies the status (Include or Exclude) of this Build Option when the build option is exported.'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.LAST_UPDATED_BY IS 'Apex developer who made last update'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.LAST_UPDATED_ON IS 'Date of last update'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.COMPONENT_COMMENT IS 'Developer Comment'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.BUILD_OPTION_ID IS 'Identifies the primary key of this component'
/

COMMENT ON COLUMN APEX_APPLICATION_BUILD_OPTIONS.COMPONENT_SIGNATURE IS 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

