CREATE VIEW APEX_UI_DEFAULTS_LOV_DATA AS
select t.schema,
       t.table_name,
       c.column_name,
       l.lov_disp_sequence,
       l.lov_disp_value,
       l.lov_return_value,
       l.last_updated_by,
       l.last_updated_on
  from wwv_flow_hnt_lov_data l,
       wwv_flow_hnt_column_info c,
       wwv_flow_hnt_table_info t
 where t.schema    = user
   and l.column_id = c.column_id
   and c.table_id  = t.table_id
/

COMMENT ON TABLE APEX_UI_DEFAULTS_LOV_DATA IS 'If you create a form, report, or tabular form that includes this column and if the appropriate Display As Type is set to use a list of values (Radio Group or Select List) then a Named List of Values will be created within the application and will be referenced by the resulting item or report column.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.SCHEMA IS 'Schema owning table.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.TABLE_NAME IS 'The table associated with the user interface defaults.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.COLUMN_NAME IS 'The column associated with the user interface defaults.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.LOV_DISP_SEQUENCE IS 'The display sequence of the static list of values record.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.LOV_DISP_VALUE IS 'The display value of the static list of values record.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.LOV_RETURN_VALUE IS 'The return value of the static list of values record.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.LAST_UPDATED_BY IS 'Auditing; user that last modified the record.'
/

COMMENT ON COLUMN APEX_UI_DEFAULTS_LOV_DATA.LAST_UPDATED_ON IS 'Auditing; date the record was last modified.'
/

