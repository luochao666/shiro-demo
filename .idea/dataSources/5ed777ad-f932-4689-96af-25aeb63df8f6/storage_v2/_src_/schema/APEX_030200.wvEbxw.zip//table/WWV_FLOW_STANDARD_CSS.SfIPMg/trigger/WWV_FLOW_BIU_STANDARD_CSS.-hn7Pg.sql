CREATE TRIGGER WWV_FLOW_BIU_STANDARD_CSS
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_STANDARD_CSS
  FOR EACH ROW
begin
    if inserting and :new.id is null then
         :new.id := wwv_flow_id.next_val;
    end if;
end;
/

