CREATE VIEW APEX_RELEASE AS
select (select wwv_flows_release from dual) version_no,
       (select wwv_flows_version from dual) api_compatibility,
       (select wwv_flow_platform.get_preference('APEX_3_0_1_PATCH') from dual) patch_applied
  from dual
/

COMMENT ON TABLE APEX_RELEASE IS 'Identifies this release of Application Express'
/

COMMENT ON COLUMN APEX_RELEASE.VERSION_NO IS 'The specific version number of this Application Express instance'
/

COMMENT ON COLUMN APEX_RELEASE.API_COMPATIBILITY IS 'The version of the API that this release is compatible with for importing applications or components'
/

COMMENT ON COLUMN APEX_RELEASE.PATCH_APPLIED IS 'The date a patch was applied if this instance was patched'
/

